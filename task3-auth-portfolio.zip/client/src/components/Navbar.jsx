
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav>
      <Link to="/home">Home</Link> | 
      <Link to="/about">About</Link> | 
      <Link to="/skills">Skills</Link> | 
      <Link to="/projects">Projects</Link> | 
      <Link to="/contact">Contact</Link> |
      <button onClick={() => {
        localStorage.removeItem("token");
        window.location.href = "/login";
      }}> Logout </button>
    </nav>
  );
}
