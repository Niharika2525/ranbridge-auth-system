
import Navbar from "../components/Navbar";
export default function Contact() {
  return (
    <>
      <Navbar />
      <h2>Contact</h2>
      <p>Email: example@gmail.com</p>
    </>
  );
}
