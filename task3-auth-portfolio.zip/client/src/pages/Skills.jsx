
import Navbar from "../components/Navbar";
export default function Skills() {
  return (
    <>
      <Navbar />
      <ul>
        <li>HTML</li><li>CSS</li><li>React</li><li>Node.js</li>
      </ul>
    </>
  );
}
