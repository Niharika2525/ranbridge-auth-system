
import Navbar from "../components/Navbar";
export default function About() {
  return (
    <>
      <Navbar />
      <h2>About Me</h2>
      <p>I am a full stack developer.</p>
    </>
  );
}
