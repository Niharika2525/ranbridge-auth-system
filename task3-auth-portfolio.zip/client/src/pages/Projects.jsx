
import Navbar from "../components/Navbar";
export default function Projects() {
  return (
    <>
      <Navbar />
      <h2>Projects</h2>
      <p>Task-2 Portfolio</p>
      <p>Task-3 Authentication System</p>
    </>
  );
}
